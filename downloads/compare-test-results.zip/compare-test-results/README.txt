여러 시험 조건을 같은 시간축에서 비교하기

입력: inputs/case_a.csv, case_b.csv, case_c.csv — 설명용 합성 데이터
이 예제는 동봉된 가상/설명용 데이터로 시작하세요.

1. ZIP을 모두 풉니다.
2. example.py가 있는 폴더에서 터미널을 엽니다.
3. python --version (검증 버전: Python 3.12.14)
4. python -m pip install -r requirements.txt
5. python example.py
6. 새 outputs 폴더에서 결과를 확인합니다.

Windows에서 python 명령이 없으면 py -3.12를 사용하세요.
설치는 인터넷 연결이 필요합니다. matplotlib 예제는 그래프 창 없이 PNG를 저장합니다.
입력 경로는 example.py 위치를 기준으로 결정됩니다.
원본은 변경하지 않습니다. outputs가 이미 있으면 덮어쓰지 않고 중지합니다.
재실행하려면 이전 outputs를 다른 이름으로 보관하거나 새 연습 폴더를 사용하세요.
오류 실험은 원본 예제 폴더를 복사한 뒤 복사본에서 수행하세요.

주요 범위: 세 개의 설명용 합성 CSV를 검증한 뒤, 같은 시간 표본과 가속도 단위를 쓰는 곡선을 한 그래프에 겹쳐 그립니다.
예상 결과: outputs/comparison_summary.csv, outputs/synthetic_comparison.png: 설명용 합성 데이터 3조건 각 6표본. 최댓값 A 1.4, B 1.1, C 1.7 m/s^2.
모든 입력·출력·그림은 설명용 합성 데이터이며 실제 차량 안전 판정을 하지 않습니다.
한계: 실제 시험 조건의 비교 가능성, 시간 동기화, 측정 불확도 및 안전성을 평가하지 않았습니다.

공식 참고 문서:
- Python 3.12 공식 문서 — csv: DictReader와 CSV 저장: https://docs.python.org/3.12/library/csv.html
- Python 3.12 공식 문서 — pathlib: 파일 경로와 새 폴더: https://docs.python.org/3.12/library/pathlib.html
- Matplotlib 공식 문서 — Figure.savefig: https://matplotlib.org/stable/api/_as_gen/matplotlib.figure.Figure.savefig.html
