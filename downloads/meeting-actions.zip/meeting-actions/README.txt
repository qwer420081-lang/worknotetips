회의록을 실행 목록으로 바꾸기 — 연습 자료
모든 메모·날짜·역할은 설명용 합성 자료입니다.
1. meeting-notes.txt의 N01~N04를 읽습니다.
2. 확정 수행 항목과 제안·미정 일정을 구분합니다.
3. expected-actions.json 및 open-questions.txt와 비교합니다.
4. ai-request.txt는 같은 정리 작업을 보조하는 서비스 중립적 요청문입니다.
5. action-checklist.txt로 담당·기한·완료조건·근거를 점검합니다.
실제 AI 서비스 호출, 담당자 확인, 이메일·메신저 전송은 수행하지 않았습니다.
