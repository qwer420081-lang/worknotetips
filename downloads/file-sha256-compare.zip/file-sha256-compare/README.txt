Python 3.12+ / standard library. Synthetic local data only.
Extract the complete archive, then run: python example.py
Expected: same_sha256=true and outputs/comparison.json.
Input files are not modified. An existing outputs directory is refused.
For another trial, extract a fresh copy elsewhere and modify copy.txt before running.
The result compares bytes, not authorship, authenticity, safety, or legal rights.
Do not change files while the program is reading them.
