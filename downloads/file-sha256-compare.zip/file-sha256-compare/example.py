"""Compare two local synthetic files without changing them."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

def main():
    output = BASE / 'outputs'
    if output.exists():
        raise ValueError('outputs already exists; choose a fresh extraction folder.')
    left, right = BASE / 'original.txt', BASE / 'copy.txt'
    hashes = [digest(left), digest(right)]
    result = {'algorithm': 'SHA-256', 'files': [left.name, right.name],
              'sha256': hashes, 'same_sha256': hashes[0] == hashes[1]}
    output.mkdir(exist_ok=False)
    with (output / 'comparison.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print('same_sha256=' + str(result['same_sha256']).lower())
    print('Created outputs/comparison.json')

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError) as error:
        raise SystemExit(f'Stopped: {error}') from error
