업무 기록을 월별 집계표와 그래프로 만들기

입력: work_log.csv
이 예제는 동봉된 가상/설명용 데이터로 시작하세요.

1. ZIP을 모두 풉니다.
2. example.py가 있는 폴더에서 터미널을 엽니다.
3. python --version (검증 버전: Python 3.12.14)
4. python -m pip install -r requirements.txt
5. python example.py
6. 새 outputs 폴더에서 결과를 확인합니다.

Windows에서 python 명령이 없으면 py -3.12를 사용하세요.
설치는 인터넷 연결이 필요합니다. matplotlib 예제는 그래프 창 없이 PNG를 저장합니다.
입력 경로는 example.py 위치를 기준으로 결정됩니다.
원본은 변경하지 않습니다. outputs가 이미 있으면 덮어쓰지 않고 중지합니다.
재실행하려면 이전 outputs를 다른 이름으로 보관하거나 새 연습 폴더를 사용하세요.
오류 실험은 원본 예제 폴더를 복사한 뒤 복사본에서 수행하세요.

주요 범위: CSV의 날짜와 작업 시간을 검증하고, 월별 기록 수와 합계 시간을 CSV와 막대그래프로 저장합니다.
예상 결과: outputs/monthly_summary.csv, outputs/monthly_hours.png: 1월 6.50시간, 2월 7.50시간, 3월 9.50시간, 총 23.50시간.
입력은 튜토리얼을 위해 만든 가상 업무 데이터입니다.
한계: 실제 인사·근태 시스템의 집계 규칙과 일치 여부는 검증 대상이 아닙니다.

공식 참고 문서:
- Python 3.12 공식 문서 — csv: DictReader와 CSV 저장: https://docs.python.org/3.12/library/csv.html
- Python 3.12 공식 문서 — pathlib: 파일 경로와 새 폴더: https://docs.python.org/3.12/library/pathlib.html
- Matplotlib 공식 문서 — Figure.savefig: https://matplotlib.org/stable/api/_as_gen/matplotlib.figure.Figure.savefig.html
