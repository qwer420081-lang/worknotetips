AI 보고서 숫자·계산·출처 검수 — 예제 자료
모든 수치는 직접 만든 합성 데이터이며 실제 성과가 아닙니다.
draft-for-review.txt는 검수 연습을 위해 작성한 초안으로 실제 AI 출력이 아닙니다.
1. source-data.json의 지표 정의를 먼저 읽습니다.
2. draft-for-review.txt의 ①~⑥을 한 문장씩 검토합니다.
3. claim-log.txt에 근거 위치와 계산을 적습니다.
4. corrected-summary.txt와 expected-checks.json으로 결과를 확인합니다.
expected-checks.json의 소수값은 표시용이며 exact_fraction은 분수로 보존한 검산값입니다.
기준 기간·단위·분모를 바꾼다면 정답도 다시 계산해야 합니다.
외부 계정, API, 업로드는 필요하지 않습니다.
