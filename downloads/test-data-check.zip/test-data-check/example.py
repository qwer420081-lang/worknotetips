"""Check time order and declared units in explanatory synthetic test data.

This demonstrates file checks only. It makes no vehicle safety assessment.
"""
import csv
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
HEADERS = ["dataset_note", "time", "time_unit", "speed", "speed_unit"]
NOTE = "설명용 합성 데이터"


def read_samples():
    samples = []
    with (BASE / "synthetic_test.csv").open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if reader.fieldnames != HEADERS:
            raise ValueError(f"Expected headers: {HEADERS}")
        for line, row in enumerate(reader, start=2):
            if None in row or any(value is None or not value.strip() for value in row.values()):
                raise ValueError(f"Row {line}: missing or extra field.")
            if row["dataset_note"] != NOTE:
                raise ValueError(f"Row {line}: explanatory synthetic-data label is required.")
            if row["time_unit"] != "s" or row["speed_unit"] != "km/h":
                raise ValueError(f"Row {line}: expected units s and km/h; no automatic conversion.")
            time, speed = float(row["time"]), float(row["speed"])
            if not math.isfinite(time) or not math.isfinite(speed):
                raise ValueError(f"Row {line}: NaN and infinite values are not supported.")
            if time < 0:
                raise ValueError(f"Row {line}: elapsed time must be nonnegative.")
            if samples and time <= samples[-1][0]:
                raise ValueError(f"Row {line}: duplicate or decreasing time; check the source.")
            samples.append((time, speed))
    if len(samples) < 2:
        raise ValueError("At least two samples are required.")
    return samples


def main():
    destination = BASE / "outputs"
    if destination.exists():
        raise ValueError("outputs already exists; rename it before running again.")
    samples = read_samples()
    times, speeds = zip(*samples)
    intervals = [right - left for left, right in zip(times, times[1:])]
    report = {
        "dataset_note": NOTE,
        "scope": "File structure and numeric checks only; no vehicle safety assessment.",
        "sample_count": len(samples), "time_unit": "s", "speed_unit": "km/h",
        "start_time": times[0], "end_time": times[-1],
        "min_interval_s": min(intervals), "max_interval_s": max(intervals),
        "min_speed_kmh": min(speeds), "max_speed_kmh": max(speeds),
        "time_strictly_increasing": True,
    }
    figure, axis = plt.subplots(figsize=(8, 4.6), layout="constrained")
    axis.plot(times, speeds, "o-", color="#2B6578", linewidth=2)
    axis.set(title="Speed trace | Explanatory synthetic data", xlabel="Elapsed time (s)", ylabel="Speed (km/h)")
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(alpha=0.2)
    destination.mkdir(exist_ok=False)
    with (destination / "data_check.json").open("x", encoding="utf-8") as file:
        json.dump(report, file, ensure_ascii=False, indent=2)
    figure.savefig(destination / "synthetic_speed.png", dpi=160)
    plt.close(figure)
    print(f"Explanatory synthetic data: {len(samples)} samples, {times[0]:g}-{times[-1]:g} s.")
    print(f"Sample interval: {min(intervals):g}-{max(intervals):g} s; units: s, km/h.")
    print("Created outputs/data_check.json and outputs/synthetic_speed.png.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, csv.Error) as error:
        raise SystemExit(f"Stopped: {error}") from error
