"""집계 함수를 손계산 기대값과 unittest로 검증합니다. 외부 AI 호출은 없습니다."""

import argparse
import csv
import json
import re
import sys
import unittest
from decimal import Decimal
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "outputs"
FIELDS = {"item", "quantity", "unit_price"}


def money(cents):
    return f"{cents // 100}.{cents % 100:02d}"


def aggregate_sales(rows):
    """문자열 딕셔너리 행을 검증하고 집계합니다. rows와 원본 파일을 변경하지 않습니다."""
    totals = {}
    row_count = total_quantity = total_cents = 0
    for number, row in enumerate(rows, start=1):
        if not isinstance(row, dict) or set(row) != FIELDS:
            raise ValueError(f"{number}행: item,quantity,unit_price 세 열이 필요합니다.")
        if any(not isinstance(value, str) for value in row.values()):
            raise ValueError(f"{number}행: 모든 값은 문자열이어야 합니다.")
        item, quantity_text, price_text = (row[key].strip() for key in ("item", "quantity", "unit_price"))
        if not item:
            raise ValueError(f"{number}행: 품목이 비어 있습니다.")
        if not re.fullmatch(r"[0-9]{1,7}", quantity_text):
            raise ValueError(f"{number}행: 수량은 0 이상의 정수여야 합니다.")
        quantity = int(quantity_text)
        if quantity > 1_000_000:
            raise ValueError(f"{number}행: 수량은 1,000,000 이하여야 합니다.")
        if not re.fullmatch(r"[0-9]{1,10}(?:\.[0-9]{1,2})?", price_text):
            raise ValueError(f"{number}행: 단가는 0 이상, 소수점 둘째 자리까지 입력하세요.")
        price = Decimal(price_text)  # 문자열에서 직접 생성해 float 오차를 피합니다.
        if price > Decimal("1000000000"):
            raise ValueError(f"{number}행: 단가는 1,000,000,000 이하여야 합니다.")
        cents = int(price * 100) * quantity
        bucket = totals.setdefault(item, {"quantity": 0, "cents": 0})
        bucket["quantity"] += quantity
        bucket["cents"] += cents
        total_quantity += quantity
        total_cents += cents
        row_count += 1
    return {
        "row_count": row_count,
        "quantity": total_quantity,
        "amount": money(total_cents),
        "by_item": [
            {"item": item, "quantity": totals[item]["quantity"], "amount": money(totals[item]["cents"])}
            for item in sorted(totals)
        ],
    }


def sale(item="펜", quantity="1", unit_price="1200.50"):
    return {"item": item, "quantity": quantity, "unit_price": unit_price}


class TestAggregate(unittest.TestCase):
    # 기대값은 검증 대상 함수로 만들지 않고 손계산한 상수로 적습니다.
    def test_empty_input(self):
        self.assertEqual(aggregate_sales([]), {"row_count": 0, "quantity": 0, "amount": "0.00", "by_item": []})

    def test_single_row(self):
        self.assertEqual(aggregate_sales([sale(quantity="3")])["amount"], "3601.50")

    def test_zero_quantity(self):
        result = aggregate_sales([sale(quantity="0")])
        self.assertEqual((result["row_count"], result["quantity"], result["amount"]), (1, 0, "0.00"))

    def test_repeated_item(self):
        result = aggregate_sales([sale(quantity="2"), sale(quantity="1")])
        self.assertEqual(result["by_item"], [{"item": "펜", "quantity": 3, "amount": "3601.50"}])

    def test_decimal_addition(self):
        result = aggregate_sales([sale(unit_price="0.10"), sale(unit_price="0.20")])
        self.assertEqual(result["amount"], "0.30")

    def test_whitespace(self):
        result = aggregate_sales([sale(item=" 펜 ", quantity=" 1 ", unit_price=" 2.00 ")])
        self.assertEqual(result["by_item"], [{"item": "펜", "quantity": 1, "amount": "2.00"}])

    def test_bad_quantity(self):
        for value in ("-1", "1.5", "", "1000001", "1e2", "１"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                aggregate_sales([sale(quantity=value)])

    def test_bad_price(self):
        for value in ("-1", "0.001", "NaN", "Infinity", "", "1,000", "1000000001"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                aggregate_sales([sale(unit_price=value)])

    def test_blank_item(self):
        with self.assertRaises(ValueError):
            aggregate_sales([sale(item=" ")])

    def test_wrong_columns(self):
        for row in ({"item": "펜"}, {**sale(), "extra": "x"}):
            with self.subTest(row=row), self.assertRaises(ValueError):
                aggregate_sales([row])

    def test_non_string(self):
        with self.assertRaises(ValueError):
            aggregate_sales([sale(quantity=True)])

    def test_upper_boundary(self):
        self.assertEqual(
            aggregate_sales([sale(quantity="1000000", unit_price="1000000000")])["amount"],
            "1000000000000000.00",
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test", action="store_true", help="단위 테스트만 실행합니다.")
    args = parser.parse_args()
    # unittest의 명시적 비교는 python -O에서도 생략되지 않습니다.
    result = unittest.TextTestRunner(verbosity=2, stream=sys.stdout).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(TestAggregate)
    )
    if not result.wasSuccessful():
        return 1
    if args.test:
        return 0
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise FileExistsError("outputs가 이미 있습니다. 기존 결과를 옮긴 뒤 실행하세요.")
    with (BASE / "input.csv").open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != ["item", "quantity", "unit_price"]:
            raise ValueError("input.csv의 열은 item,quantity,unit_price 순서여야 합니다.")
        actual = aggregate_sales(reader)
    expected = json.loads((BASE / "expected.json").read_text(encoding="utf-8"))
    if actual != expected:
        raise ValueError("예제 집계가 expected.json의 손계산 기대값과 다릅니다.")
    OUTPUT.mkdir()
    with (OUTPUT / "summary.json").open("x", encoding="utf-8") as stream:
        json.dump(actual, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    with (OUTPUT / "verification.txt").open("x", encoding="utf-8") as stream:
        stream.write(f"unittest: {result.testsRun}개 통과\n예제 기대값: 일치\n외부 AI API 호출: 없음\n")
    print(f"완료: {actual['row_count']}행, 수량 {actual['quantity']}, 금액 {actual['amount']}")
    print(OUTPUT)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, csv.Error) as error:
        print(f"중지: {error}", file=sys.stderr)
        raise SystemExit(2)
