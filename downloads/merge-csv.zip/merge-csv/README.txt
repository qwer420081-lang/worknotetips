워크노트 예제: 여러 CSV를 합치고 원본 파일명 남기기

준비: Python 3.12 이상. 추가 패키지는 없습니다.
압축을 푼 예제 폴더에서 터미널을 열고 실행합니다.
  python example.py
Windows 대체 명령: py example.py / macOS·Linux 대체 명령: python3 example.py

입력: inputs/sales_01.csv (2행), inputs/sales_02.csv (3행)
입력 헤더: date,item,quantity,unit_price (이름 및 순서가 같아야 합니다.)
출력: outputs/merged.csv (헤더 다음 데이터 5행)
출력 마지막 열 source_file에 원본 파일명이 들어갑니다.
쉼표와 큰따옴표가 들어간 품목명도 csv 모듈로 보존합니다.
파일은 이름순, 각 파일의 행은 기존 순서대로 처리합니다. 중복 행을 제거하지 않습니다.
원본은 변경하지 않습니다. outputs가 있으면 덮어쓰지 않고 중지합니다.
다시 실행하려면 outputs를 옮기거나 새 폴더에 압축을 풉니다.
열 누락/추가, 잘못된 헤더, 빈 값, CSV 파일 없음은 오류로 중지합니다.
CSV 구조를 검사하며 날짜의 의미나 금액의 정확성까지 검증하지는 않습니다.
모든 CSV를 메모리에 모으므로 작은 업무 파일로 시작하세요.
이 데이터는 개인정보가 없는 직접 작성 합성 자료입니다.
