"""Offline regression tests. Every CLI execution uses a temporary directory."""
from __future__ import annotations

import ast
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parent
SCRIPT = BASE / "example.py"


class ConverterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="worknote-json-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "input.json"
        self.source.write_bytes((BASE / "sample.json").read_bytes())
        self.output = self.root / "result"

    def set_input(self, text: str | bytes) -> None:
        self.source.write_bytes(text.encode("utf-8") if isinstance(text, str) else text)

    def run_cli(self, *, output: Path | None = None, fields: list[str] | None = None):
        before = self.source.read_bytes() if self.source.exists() else None
        command = [sys.executable, "-X", "utf8", str(SCRIPT), str(self.source),
                   "--output-dir", str(output if output is not None else self.output)]
        if fields is not None:
            command += ["--fields", *fields]
        result = subprocess.run(command, cwd=self.root, capture_output=True,
                                text=True, encoding="utf-8", timeout=10)
        after = self.source.read_bytes() if self.source.exists() else None
        self.assertEqual(before, after, "Source bytes changed")
        if before is not None:
            self.assertEqual(hashlib.sha256(before).hexdigest(),
                             hashlib.sha256(after).hexdigest())
        return result

    def read_csv(self, name: str) -> list[dict[str, str]]:
        with (self.output / name).open(encoding="utf-8", newline="") as stream:
            return list(csv.DictReader(stream))

    def summary(self) -> dict:
        return json.loads((self.output / "summary.json").read_text(encoding="utf-8"))

    def assert_rejected(self, text: str | bytes, message: str) -> None:
        self.set_input(text)
        result = self.run_cli()
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertIn(message, result.stderr)
        self.assertFalse(self.output.exists(), "Invalid input created an output directory")

    def test_01_sample_matches_independent_expected_files(self):
        result = self.run_cli()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(set(p.name for p in self.output.iterdir()),
                         {"converted.csv", "field_issues.csv", "summary.json"})
        for expected in (BASE / "expected").iterdir():
            self.assertEqual((self.output / expected.name).read_bytes(), expected.read_bytes())
        self.assertEqual(len(self.read_csv("converted.csv")), 4)
        self.assertEqual(len(self.read_csv("field_issues.csv")), 4)
        self.assertEqual(self.summary()["missing_key_cells"], 2)

    def test_02_rerun_refused_and_existing_outputs_unchanged(self):
        self.assertEqual(self.run_cli().returncode, 0)
        before = {p.name: p.read_bytes() for p in self.output.iterdir()}
        result = self.run_cli()
        self.assertEqual(result.returncode, 3)
        self.assertIn("E_OUTPUT_EXISTS", result.stderr)
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.output.iterdir()})

    def test_03_malformed_json(self):
        self.assert_rejected('[{"item": "A",}]', "Invalid JSON at line")

    def test_04_top_level_must_be_array(self):
        for text in ('{}', 'null', '"text"', '1', 'true'):
            with self.subTest(text=text):
                self.assert_rejected(text, "must be an array")

    def test_05_missing_keys_reported_without_dropping_row(self):
        self.set_input('[{"item":"가상부품-X"}]')
        self.assertEqual(self.run_cli().returncode, 0)
        self.assertEqual(self.read_csv("converted.csv"), [{"item":"가상부품-X", "quantity":"", "unit":""}])
        self.assertEqual(self.read_csv("field_issues.csv"), [
            {"row_number":"1", "field":"quantity", "issue":"missing_key"},
            {"row_number":"1", "field":"unit", "issue":"missing_key"},
        ])
        self.assertEqual(self.summary()["missing_key_cells"], 2)
        self.assertEqual(self.summary()["rows_with_missing_keys"], 1)

    def test_06_null_and_empty_are_not_missing_keys(self):
        self.set_input('[{"item":"A","quantity":null,"unit":""}]')
        self.assertEqual(self.run_cli().returncode, 0)
        summary = self.summary()
        self.assertEqual((summary["missing_key_cells"], summary["null_cells"],
                          summary["empty_string_cells"]), (0, 1, 1))

    def test_07_existing_empty_directory_refused(self):
        self.output.mkdir()
        self.assertEqual(self.run_cli().returncode, 3)
        self.assertEqual(list(self.output.iterdir()), [])

    def test_08_input_path_cannot_be_output(self):
        self.assertEqual(self.run_cli(output=self.source).returncode, 3)

    def test_09_empty_array_produces_headers(self):
        self.set_input('[]')
        self.assertEqual(self.run_cli().returncode, 0)
        self.assertEqual((self.output / "converted.csv").read_text(encoding="utf-8"), "item,quantity,unit\n")
        self.assertEqual(self.read_csv("field_issues.csv"), [])
        self.assertEqual(self.summary()["output_rows"], 0)

    def test_10_records_must_be_objects(self):
        for text in ('[1]', '[null]', '[[]]', '["A"]'):
            with self.subTest(text=text):
                self.assert_rejected(text, "must be an object")

    def test_11_extra_keys_rejected_until_fields_explicit(self):
        text = '[{"item":"A","quantity":1,"unit":"ea","note":"synthetic"}]'
        self.assert_rejected(text, "unlisted keys")
        result = self.run_cli(fields=["item", "quantity", "unit", "note"])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.read_csv("converted.csv")[0]["note"], "synthetic")

    def test_12_nested_values_rejected(self):
        for text in ('[{"item":{"code":"A"}}]', '[{"item":["A"]}]'):
            with self.subTest(text=text):
                self.assert_rejected(text, "nested value")

    def test_13_duplicate_json_keys_rejected(self):
        self.assert_rejected('[{"item":"A","item":"B"}]', "Duplicate key")

    def test_14_nonstandard_numbers_rejected(self):
        for token in ("NaN", "Infinity", "-Infinity"):
            with self.subTest(token=token):
                self.assert_rejected('[{"quantity":' + token + '}]', "Non-standard JSON number")

    def test_15_utf8_bom_accepted_and_bad_utf8_rejected(self):
        self.assert_rejected(b'[{"item":"\xff"}]', "E_INPUT")
        self.set_input(b'\xef\xbb\xbf' + (BASE / "sample.json").read_bytes())
        self.assertEqual(self.run_cli().returncode, 0)
        self.assertEqual(self.summary()["output_rows"], 4)

    def test_16_csv_quotes_newlines_and_decimal_roundtrip(self):
        for index, separator in enumerate(("\n", "\r", "\r\n")):
            with self.subTest(separator=repr(separator)):
                self.output = self.root / f"quoted-{index}"
                item = '부품, "A"' + separator + '두 번째 줄'
                self.set_input('[{"item":' + json.dumps(item) + ',"quantity":0.10,"unit":false}]')
                self.assertEqual(self.run_cli().returncode, 0)
                self.assertEqual(self.read_csv("converted.csv"), [{"item":item, "quantity":"0.10", "unit":"false"}])
                self.assertEqual(self.summary()["reported_issue_cells"], 0)

    def test_17_zero_false_and_whitespace_are_preserved(self):
        self.set_input('[{"item":"  A  ","quantity":0,"unit":false}]')
        self.assertEqual(self.run_cli().returncode, 0)
        self.assertEqual(self.read_csv("converted.csv"), [{"item":"  A  ", "quantity":"0", "unit":"false"}])
        self.assertEqual(self.summary()["reported_issue_cells"], 0)

    def test_18_oversized_input_rejected(self):
        self.assert_rejected(b' ' * (5 * 1024 * 1024 + 1), "5 MiB limit")

    def test_19_missing_input_and_missing_output_parent(self):
        result = self.run_cli(output=self.root / "absent" / "result")
        self.assertEqual(result.returncode, 4)
        self.assertFalse((self.root / "absent").exists())
        self.source.unlink()  # Fixture setup only; example.py never deletes files.
        result = self.run_cli()
        self.assertEqual(result.returncode, 4)
        self.assertIn("E_READ", result.stderr)
        self.assertFalse(self.output.exists())

    def test_20_duplicate_or_blank_field_names_rejected(self):
        for fields in (["item", "item"], [" "]):
            with self.subTest(fields=fields):
                result = self.run_cli(fields=fields)
                self.assertEqual(result.returncode, 2)
                self.assertFalse(self.output.exists())

    def test_21_python312_syntax_and_stdlib_imports(self):
        # A best-effort syntax check, NOT execution on a Python 3.12 runtime.
        for path in (SCRIPT, Path(__file__)):
            tree = ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 12))
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [alias.name.split(".")[0] for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names = [node.module.split(".")[0]]
                for name in names:
                    self.assertIn(name, sys.stdlib_module_names)

    def test_22_new_output_name_allows_another_run(self):
        self.assertEqual(self.run_cli().returncode, 0)
        second = self.root / "result-second"
        self.assertEqual(self.run_cli(output=second).returncode, 0)
        for original in self.output.iterdir():
            self.assertEqual(original.read_bytes(), (second / original.name).read_bytes())


if __name__ == "__main__":
    unittest.main(verbosity=2)
