워크노트 예제: 파일명 변경 계획을 확인하고 복사본 만들기

준비: Python 3.12 이상. 추가 패키지는 없습니다.
압축을 푼 예제 폴더에서 터미널을 열고 먼저 실행합니다.
  python example.py
이 명령은 미리보기만 출력하고 폴더나 파일을 만들지 않습니다.
3개 이름을 확인한 뒤 실제 복사본을 만듭니다.
  python example.py --apply
Windows 대체 실행기: py / macOS·Linux 대체 실행기: python3

입력: source_files/ 원본 3개, mapping.csv의 old_name,new_name 열
출력: outputs/renamed/의 새 이름 파일 3개와 outputs/manifest.csv
원본 파일을 rename하지 않습니다. 새 이름으로 파일 내용을 복사합니다.
기대 파일명: note-draft.txt, quote-001.txt, photo-notes.txt
새 이름끼리 대소문자만 달라도 충돌로 판단하고 복사 전에 전체 중지합니다.
원본 매핑 누락, 없는 원본, 경로가 포함된 이름, 예약 이름도 거부합니다.
outputs가 이미 있으면 미리보기도 중지하며 기존 결과를 덮어쓰지 않습니다.
다시 연습하려면 outputs를 다른 이름으로 옮기거나 새 폴더에 압축을 풉니다.
검증 뒤 디스크 오류가 발생하면 부분 출력은 남을 수 있습니다. 원본은 유지됩니다.
파일 내용만 복사하며 원본 생성/수정 시각이나 접근 권한 보존을 보장하지 않습니다.
이 데이터는 개인정보가 없는 직접 작성 합성 자료입니다.
