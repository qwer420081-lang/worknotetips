Sample inventory
