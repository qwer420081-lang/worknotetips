엑셀 중복 행을 찾아 검토용 파일로 분리하기

입력: orders.xlsx（Orders 시트）
이 예제는 동봉된 가상/설명용 데이터로 시작하세요.

1. ZIP을 모두 풉니다.
2. example.py가 있는 폴더에서 터미널을 엽니다.
3. python --version (검증 버전: Python 3.12.14)
4. python -m pip install -r requirements.txt
5. python example.py
6. 새 outputs 폴더에서 결과를 확인합니다.

Windows에서 python 명령이 없으면 py -3.12를 사용하세요.
설치는 인터넷 연결이 필요합니다. matplotlib 예제는 그래프 창 없이 PNG를 저장합니다.
입력 경로는 example.py 위치를 기준으로 결정됩니다.
원본은 변경하지 않습니다. outputs가 이미 있으면 덮어쓰지 않고 중지합니다.
재실행하려면 이전 outputs를 다른 이름으로 보관하거나 새 연습 폴더를 사용하세요.
오류 실험은 원본 예제 폴더를 복사한 뒤 복사본에서 수행하세요.

주요 범위: 네 열이 완전히 같은 행을 찾아 원본 행 번호와 함께 새 엑셀 파일로 모읍니다. 첫 행도 포함해 중복 묶음을 확인합니다.
예상 결과: outputs/duplicate_review.xlsx: Duplicates 4행, Unique 4행. 원본 데이터 8행, 중복 묶음 2개.
입력은 튜토리얼을 위해 만든 가상 업무 데이터입니다.
한계: Excel 데스크톱 앱에서의 표시와 대용량 성능은 검증하지 않았습니다.

공식 참고 문서:
- openpyxl 공식 튜토리얼 — 워크북 읽기와 저장: https://openpyxl.readthedocs.io/en/stable/tutorial.html
- Python 3.12 공식 문서 — pathlib: 파일 경로와 새 폴더: https://docs.python.org/3.12/library/pathlib.html
